# Android Quiz App

A native multi-screen Android quiz application built using Java, XML, and Android Studio.

This project was developed as part of my Mobile Web Application Development module at the University of West London.

## Features

- Multi-screen quiz flow
- Two quiz categories: Software Engineering and Data Structures
- Normal mode and learning mode
- Input validation when no answer is selected
- Randomised question selection
- Score tracking
- Review screen before saving the result
- Top 10 leaderboard using SharedPreferences and Gson
- Clean XML-based user interface
- Git/GitHub version control

## Tech Stack

- Java
- XML
- Android Studio
- Gradle
- SharedPreferences
- Gson
- Git
- GitHub

## Demo

YouTube demo: https://www.youtube.com/watch?v=xNAfgyo_PEg

## Screenshots

Add screenshots here after uploading images into the `screenshots` folder:

![Start Screen](screenshots/start-screen.png)
![Quiz Screen](screenshots/quiz-screen.png)
![Result Screen](screenshots/result-screen.png)

## How to Run

1. Clone the repository:

```bash
git clone https://github.com/aymanelmoudden177-lab/android-quiz-app.git
```

2. Open the project in Android Studio.
3. Let Gradle sync.
4. Run the app on an emulator or Android device.

## Project Structure

```text
app/src/main/java/com/Ayman/quizapp/
├── MainActivity.java
├── QuizActivity.java
├── ReviewActivity.java
├── ScoreActivity.java
├── QuizData.java
├── Question.java
└── ScoreEntry.java
```

## What I Learned

Through this project, I improved my understanding of:

- Android activity structure
- XML layouts
- User input validation
- Quiz logic and score tracking
- SharedPreferences for local storage
- Gradle project structure
- Using Git and GitHub for version control

## Author

Ayman El Moudden Afilal  
Junior Android Developer | BSc Information Technology Student  
LinkedIn: https://www.linkedin.com/in/ayman-el-moudden-afilal  
GitHub: https://github.com/aymanelmoudden177-lab
